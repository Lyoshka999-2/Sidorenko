import UIKit
import Darwin

//1. Решите квадратное уравнение. a*x^2+b*x+c=0

let a = 3

let b = 2

let c = 6

if a != 0 {
    
    let D = (b*b) - 4*a*c
        
    let x = (-((b)/(2 * a)))
        
    let x1 = (-b + ((D*D)/(2 * a)))

    let x2 = (-b - ((D*D)/(2 * a)))
        
    if D < 0 {
        print("Корней нет")
            
        }
        
    if D == 0 {
        print("Один корень")
        print(x)
            
        }
        
    if D > 0 {
        print("Два корня")
        print(x1,"и", x2)
        }
} else {
    print("Ops")
}



// 2. Даны катеты прямоугольника.

let katA: Double = 6.3

let katB: Double = 5.2

let Gipot: Double = sqrt((katA*katA) + (katB*katB))

let Plosh: Double = Double(((katA*katB)/2))

let Perim: Double = ((katA + katB) + Gipot)

print(" ")

print("Гипотенуза", "=", Gipot)
print("Площадь", "=", Plosh)
print("Периметр", "=", Perim)

print(" ")

//3. Пользователь вносит вклад.

let stavka: Double = 5.1

let vklad: Double = 45000

let srokVklada: Double = 5

let summaItog: Double = (vklad*(1 + ((stavka*srokVklada)/100)))

print(summaItog)


